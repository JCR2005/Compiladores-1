import React, { useState } from 'react';
import './App.css';
function App() {
  const [codigo, setCodigo] = useState('');
  const [salida, setSalida] = useState('');
  const [symbolTable, setSymbolTable] = useState([]);
  const [tokens, setTokens] = useState([]);
  const [vistaActual, setVistaActual] = useState('salida');
  const [isLoading, setIsLoading] = useState(false);

  const handleArchivo = (e) => {
    const archivo = e.target.files[0];
    if (archivo && archivo.name.endsWith('.objc')) {
      const reader = new FileReader();
      reader.onload = (event) => {
        setCodigo(event.target.result);
      };
      reader.readAsText(archivo);
    } else {
      alert('Solo se permite cargar archivos con extensión .objc');
    }
  };

  const handleInterpretar = async () => {
    if (!codigo.trim()) {
      alert('Por favor ingrese código para interpretar');
      return;
    }

    setIsLoading(true);
    try {
      const response = await fetch('http://127.0.0.1:5000/interpret', {
        method: 'POST',
        headers: {
          'Content-Type': 'application/json',
        },
        body: JSON.stringify({ code: codigo })
      });
      
      const data = await response.json();

      if (data.status === 'success') {
        setSalida(data.output || 'Interpretación completada sin salida');
        setSymbolTable(data.symbol_table || []);
        setTokens(data.tokens || []);
        setVistaActual('salida');
        console.log('Respuesta del servidor:', data);
      } else {
        setSalida(`Error: ${data.message}`);
        setSymbolTable([]);
        setTokens([]);
      }
    } catch (error) {
      console.error('Error completo:', error);
      let errorMessage = 'Error desconocido';
      
      if (error.name === 'TypeError' && error.message.includes('fetch')) {
        errorMessage = 'No se puede conectar al servidor. Verifique que esté ejecutándose en el puerto 5000.';
      } else {
        errorMessage = error.message || 'Error de conexión';
      }
      
      setSalida(`Error de conexión: ${errorMessage}`);
      setSymbolTable([]);
      setTokens([]);
    } finally {
      setIsLoading(false);
    }
  };

  const mostrarTablaSimbolos = () => {
    if (symbolTable.length === 0) {
      alert('Primero debe interpretar el código para generar la tabla de símbolos');
      return;
    }
    setVistaActual('simbolos');
  };

  const mostrarTokens = () => {
    if (tokens.length === 0) {
      alert('Primero debe interpretar el código para generar los tokens');
      return;
    }
    setVistaActual('tokens');
  };

  const renderSymbolTable = () => (
    <div style={{ marginTop: '20px' }}>
      <h4 style={{ color: '#ffffff' }}>Tabla de Símbolos ({symbolTable.length} elementos)</h4>
      <table style={{ 
        width: '100%', 
        borderCollapse: 'collapse', 
        marginTop: '10px', 
        backgroundColor: '#2d2d2d', 
        color: '#fff' 
      }}>
        <thead>
          <tr style={{ backgroundColor: '#404040' }}>
           <th style={{ border: '1px solid #444', padding: '12px', textAlign: 'left' }}>ID</th>
          <th style={{ border: '1px solid #444', padding: '12px', textAlign: 'left' }}>Tipo</th>
          <th style={{ border: '1px solid #444', padding: '12px', textAlign: 'left' }}>Tipo Valor</th>
          <th style={{ border: '1px solid #444', padding: '12px', textAlign: 'left' }}>Ámbito</th>
          <th style={{ border: '1px solid #444', padding: '12px', textAlign: 'left' }}>Valor</th>
          <th style={{ border: '1px solid #444', padding: '12px', textAlign: 'left' }}>Línea</th>
          <th style={{ border: '1px solid #444', padding: '12px', textAlign: 'left' }}>Columna</th>
          </tr>
        </thead>
        <tbody>
          {symbolTable.map((item, index) => (
            <tr key={index} style={{ 
              backgroundColor: index % 2 === 0 ? '#353535' : '#2d2d2d' 
            }}>
              <td style={{ 
                border: '1px solid #666', 
                padding: '10px', 
                fontWeight: 'bold', 
                color: '#4CAF50' 
              }}>
                {item.id}
              </td>
              <td style={{ border: '1px solid #666', padding: '10px' }}>{item.tipo}</td>
              <td style={{ 
                border: '1px solid #666', 
                padding: '10px', 
                color: '#FF9800' 
              }}>
                {item.tipo_valor}
              </td>
              <td style={{ border: '1px solid #666', padding: '10px' }}>{item.ambito}</td>
              <td style={{ 
                border: '1px solid #666', 
                padding: '10px', 
                color: '#2196F3' 
              }}>
                {item.valor !== null ? JSON.stringify(item.valor) : 'null'}
              </td>
              <td style={{ 
                border: '1px solid #666', 
                padding: '10px', 
                textAlign: 'center' 
              }}>
                {item.linea}
              </td>
              <td style={{ 
                border: '1px solid #666', 
                padding: '10px', 
                textAlign: 'center' 
              }}>
                {item.columna}
              </td>
            </tr>
          ))}
        </tbody>
      </table>
    </div>
  );

  const renderTokens = () => (
    <div style={{ marginTop: '20px' }}>
      <h4>Análisis Léxico - Tokens ({tokens.length} elementos)</h4>
      <table style={{ 
        width: '100%', 
        borderCollapse: 'collapse', 
        marginTop: '10px', 
        backgroundColor: '#2d2d2d', 
        color: '#fff' 
      }}>
        <thead>
          <tr style={{ backgroundColor: '#404040' }}>
            <th style={{ border: '1px solid #666', padding: '12px', textAlign: 'left' }}>Tipo</th>
            <th style={{ border: '1px solid #666', padding: '12px', textAlign: 'left' }}>Valor</th>
            <th style={{ border: '1px solid #666', padding: '12px', textAlign: 'left' }}>Línea</th>
            <th style={{ border: '1px solid #666', padding: '12px', textAlign: 'left' }}>Columna</th>
          </tr>
        </thead>
        <tbody>
          {tokens.map((token, index) => (
            <tr key={index} style={{ 
              backgroundColor: index % 2 === 0 ? '#353535' : '#2d2d2d' 
            }}>
              <td style={{ 
                border: '1px solid #666', 
                padding: '10px', 
                color: '#4CAF50', 
                fontWeight: 'bold' 
              }}>
                {token.type}
              </td>
              <td style={{ 
                border: '1px solid #666', 
                padding: '10px', 
                color: '#2196F3' 
              }}>
                {JSON.stringify(token.value)}
              </td>
              <td style={{ 
                border: '1px solid #666', 
                padding: '10px', 
                textAlign: 'center' 
              }}>
                {token.line}
              </td>
              <td style={{ 
                border: '1px solid #666', 
                padding: '10px', 
                textAlign: 'center' 
              }}>
                {token.column}
              </td>
            </tr>
          ))}
        </tbody>
      </table>
    </div>
  );

  const renderContenidoPrincipal = () => {
    switch (vistaActual) {
      case 'simbolos':
        return symbolTable.length > 0 ? renderSymbolTable() : (
          <div style={{ padding: '20px', textAlign: 'center', color: '#666' }}>
            No hay tabla de símbolos generada. Primero interprete el código.
          </div>
        );
      case 'tokens':
        return tokens.length > 0 ? renderTokens() : (
          <div style={{ padding: '20px', textAlign: 'center', color: '#666' }}>
            No hay tokens generados. Primero interprete el código.
          </div>
        );
      case 'salida':
      default:
        return (
          <>
            <label style={{ color: '#ffffff' }}>Salida:</label>
            <textarea
              style={{ 
                width: '100%', 
                height: '200px',
                fontFamily: 'monospace',
                fontSize: '14px',
                padding: '12px',
                backgroundColor: '#1e1e1e', 
                color: '#ffffff',
                border: '1px solid #444',
                borderRadius: '8px',
                resize: 'vertical'
              }}
              readOnly
              value={salida}
              placeholder="Salida del intérprete"
            />
          </>
        );
    }
  };

  return (
    <div className="App">
      <h3>Obj-C Web Analyzer</h3>
      
      <div style={{ margin: '20px 0' }}>
        <input
          type="file"
          id="archivo"
          accept=".objc"
          onChange={handleArchivo}
          style={{ display: 'none' }}
        />
        <button onClick={() => document.getElementById('archivo').click()}>
          Cargar Archivo
        </button>
        <button 
          onClick={handleInterpretar} 
          disabled={isLoading}
          style={{ 
            marginLeft: '10px',
            backgroundColor: isLoading ? '#ccc' : '#4CAF50',
            cursor: isLoading ? 'not-allowed' : 'pointer'
          }}
        >
          {isLoading ? 'Interpretando...' : 'Interpretar'}
        </button>
      </div>

      <label>Entrada:</label>
      <textarea
        style={{ 
          width: '100%', 
          height: '150px',
          fontFamily: 'monospace',
          fontSize: '14px',
          padding: '10px'
        }}
        placeholder="Ingresar Código"
        value={codigo}
        onChange={(e) => setCodigo(e.target.value)}
      />

      <div style={{ margin: '20px 0' }}>
        <button
          onClick={() => setVistaActual('salida')}
          style={{
            backgroundColor: vistaActual === 'salida' ? '#4CAF50' : '#666',
            color: 'white',
            border: 'none',
            padding: '10px 15px',
            margin: '0 5px',
            cursor: 'pointer',
            borderRadius: '4px'
          }}
        >
          Salida
        </button>
        <button
          onClick={() => alert('Reporte de errores no implementado')}
          style={{
            backgroundColor: '#FF9800',
            color: 'white',
            border: 'none',
            padding: '10px 15px',
            margin: '0 5px',
            cursor: 'pointer',
            borderRadius: '4px'
          }}
        >
          Reporte de Errores
        </button>
        <button
          onClick={mostrarTablaSimbolos}
          style={{
            backgroundColor: vistaActual === 'simbolos' ? '#2196F3' : '#666',
            color: 'white',
            border: 'none',
            padding: '10px 15px',
            margin: '0 5px',
            cursor: 'pointer',
            borderRadius: '4px'
          }}
        >
          Tabla de Símbolos {symbolTable.length > 0 && `(${symbolTable.length})`}
        </button>
        <button
          onClick={mostrarTokens}
          style={{
            backgroundColor: vistaActual === 'tokens' ? '#9C27B0' : '#666',
            color: 'white',
            border: 'none',
            padding: '10px 15px',
            margin: '0 5px',
            cursor: 'pointer',
            borderRadius: '4px'
          }}
        >
          Tokens {tokens.length > 0 && `(${tokens.length})`}
        </button>
        <button
          onClick={() => alert('AST no implementado')}
          style={{
            backgroundColor: '#795548',
            color: 'white',
            border: 'none',
            padding: '10px 15px',
            margin: '0 5px',
            cursor: 'pointer',
            borderRadius: '4px'
          }}
        >
          AST
        </button>
      </div>

      {/* Área de contenido principal */}
      <div style={{ 
        minHeight: '200px', 
        border: '1px solid #444', 
        borderRadius: '8px',     
        backgroundColor: '#1e1e1e', 
        padding: '15px',         
        color: '#ffffff'        
      }}>
        {renderContenidoPrincipal()}
      </div>

      {/* Información de estado */}
      {symbolTable.length > 0 && (
        <div style={{ 
          marginTop: '20px', 
          padding: '10px', 
          backgroundColor: '#e8f5e8', 
          border: '1px solid #4CAF50', 
          borderRadius: '5px' 
        }}>
          <strong>Estado:</strong> Tabla de símbolos generada correctamente con {symbolTable.length} elemento(s)
        </div>
      )}
      
      {isLoading && (
        <div style={{ 
          marginTop: '10px', 
          padding: '10px', 
          backgroundColor: '#fff3cd', 
          border: '1px solid #ffeaa7', 
          borderRadius: '5px',
          textAlign: 'center'
        }}>
          <strong>Procesando...</strong> Interpretando código, por favor espere.
        </div>
      )}
    </div>
  );
}

export default App;