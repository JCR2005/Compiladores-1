class Continue(Exception): 
    def __init__(self, fila= None, columna = None):
        self.fila = fila
        self.columna = columna

    def interpretar(self, ts):
        raise Continue(self.fila, self.columna)