class Printnl:
    def __init__(self, expresion):
        self.expresion = expresion

    def interpretar(self, pila_tabla):

        resultado = self.expresion.interpretar(pila_tabla)
        if resultado is not None:
            print(resultado)
      
        '''if(self.expresion.interpretar(pila_tabla) is None):
            pass
        else:

            print(self.expresion.interpretar(pila_tabla))'''
       
class Declaracion_asignacion:
    def __init__(self, id, tipo, tipo_valor, ambito, valor, linea, columna):
        self.id=id
        self.tipo = tipo          
        self.tipo_valor = tipo_valor  
        self.ambito= ambito
        self.valor= valor
        self.linea= linea
        self.columna= columna

    def interpretar(self,pila_tabla):
        ambito_actual = pila_tabla.ambito_actual()
        self.ambito = ambito_actual

        valor=self.valor.interpretar(pila_tabla)
        
         # validar el tipo de dato
        if self.tipo_valor == 'int':
            if isinstance(valor, bool):
                valor = 1 if valor else 0
            elif isinstance(valor, str) and valor.lower() in ["true", "false"]:
                valor = 1 if valor.lower() == "true" else 0
            elif not isinstance(valor, int):
                print(f"Error: Se esperaba un int para la variable '{self.id}', pero se recibió {type(valor).__name__}(línea {self.linea}, columna {self.columna}).")
                return None

        elif  self.tipo_valor == 'float' and not isinstance(valor, float):
            print(f"Error: Se esperaba un float para la variable '{self.id}', pero se recibió {type(valor).__name__}(línea {self.linea}, columna {self.columna}).")
            return None
        elif  self.tipo_valor == 'str' and not isinstance(valor, str):
            print(f"Error: Se esperaba un str para la variable '{self.id}', pero se recibió {type(valor).__name__}(línea {self.linea}, columna {self.columna}).")
            return None
        elif  self.tipo_valor == 'char' and not (isinstance(valor, str) and len(valor) == 1):
            print(f"Error: Se esperaba un char para la variable '{self.id}', pero se recibió {type(valor).__name__}(línea {self.linea}, columna {self.columna}).")
            return None
        elif  self.tipo_valor == 'bool':
            if isinstance(valor, bool):
                pass
            elif isinstance(valor, bool) and valor.upper() in ["TRUE", "FALSE"]:
                valor = True if valor.upper() == "TRUE" else False
            else:
                print(f"Error: Se esperaba un bool para la variable '{self.id}', pero se recibió {type(valor).__name__}(línea {self.linea}, columna {self.columna}).")

                return None
            
        pila_tabla.cima().insertar(self.id,self.tipo, self.tipo_valor , self.ambito,valor,  self.linea, self.columna);
            
class Asignacion:
    def __init__(self, id, valor,linea, columna):
        self.id=id
        self.valor=valor    
        self.linea=linea
        self.columna=columna

    def interpretar(self,pila_tabla):
        valor=self.valor.interpretar(pila_tabla)
        tipo_valor= pila_tabla.obtener_tipo_valor_con_alcance(self.id)
        #####
        if tipo_valor == 'int':
            if isinstance(valor, bool):
                valor = 1 if valor else 0
            elif isinstance(valor, str) and valor.lower() in ["true", "false"]:
                valor = 1 if valor.lower() == "true" else 0
            elif not isinstance(valor, int):
                print(f"Error: Se esperaba un int para la variable '{self.id}', pero se recibió {type(valor).__name__}(línea {self.linea}, columna {self.columna}).")
                return None
        #####
        elif  tipo_valor == 'float' and not isinstance(valor, float):
            print(f"Error: Se esperaba un float para la variable '{self.id}', pero se recibió {type(valor).__name__}(línea {self.linea}, columna {self.columna}).")
            return None
        elif  tipo_valor == 'str' and not isinstance(valor, str):
            print(f"Error: Se esperaba un str para la variable '{self.id}', pero se recibió {type(valor).__name__}(línea {self.linea}, columna {self.columna}).")
            return None
        elif  tipo_valor == 'char' and not (isinstance(valor, str) and len(valor) == 1):
            print(f"Error: Se esperaba un char para la variable '{self.id}', pero se recibió {type(valor).__name__}(línea {self.linea}, columna {self.columna}).")
            return None
        elif  tipo_valor == 'bool':
            if isinstance(valor, bool):
                pass
            elif isinstance(valor, str) and valor.upper() in ["TRUE", "FALSE"]:
                valor = True if valor.upper() == "TRUE" else False
            else:
                print(f"Error: Se esperaba un bool para la variable '{self.id}', pero se recibió {type(valor).__name__}(línea {self.linea}, columna {self.columna}).")
                return None
            #
        pila_tabla.actualizar_valor_con_alcance(self.id,valor,self.linea, self.columna)

class Declaracion:
    def __init__(self,  id, tipo, tipo_valor, ambito, linea, columna ):
        self.id=id
        self.tipo = tipo          
        self.tipo_valor = tipo_valor  
        self.ambito= ambito
        self.linea= linea
        self.columna= columna

    def interpretar(self,pila_tabla):
        ambito_actual = pila_tabla.ambito_actual()
        self.ambito = ambito_actual
        
        pila_tabla.cima().insertar(self.id,self.tipo, self.tipo_valor , self.ambito, None,  self.linea, self.columna);