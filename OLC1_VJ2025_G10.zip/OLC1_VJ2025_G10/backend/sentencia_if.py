from tablaSimbolos import TablaSimbolos

class If:
    # Clase que representa una sentencia if-else en el lenguaje
    def __init__(self, condicion, instrucciones_if, instrucciones_else):
        self.condicion = condicion # La condición del if, que debe ser una expresión
        self.instrucciones_if = instrucciones_if # Instrucciones a ejecutar si la condición es verdadera
        self.instrucciones_else = instrucciones_else # Instrucciones a ejecutar si la condición es falsa o tiene un else if

    def interpretar(self, pila_tabla):
        condicion_resultado = self.condicion.interpretar(pila_tabla)

        if not isinstance(condicion_resultado, bool):
            print("Error: la condición del if no es booleana.")
            return None

        if condicion_resultado:
            nombre_ambito = pila_tabla.generar_nombre_ambito("if")
            pila_tabla.apilar(TablaSimbolos(), nombre_ambito)

            try:
                for instr in self.instrucciones_if:
                    instr.interpretar(pila_tabla)
            finally:
                pila_tabla.desapilar()
        elif self.instrucciones_else is not None:
            nombre_ambito = pila_tabla.generar_nombre_ambito("else")
            pila_tabla.apilar(TablaSimbolos(), nombre_ambito)

            try:
                if isinstance(self.instrucciones_else, list):
                    for instr in self.instrucciones_else:
                        instr.interpretar(pila_tabla)
                else:
                    self.instrucciones_else.interpretar(pila_tabla)
            finally:
                pila_tabla.desapilar()