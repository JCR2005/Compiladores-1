from lexer import lexer  # Importa el lexer
from parser import parser, ambitos  # Importa el parser
from reportes.reporte_ast import ReporteAST 
from reportes.nodo_ast import NodoRaiz

data = '''

// IF ANIDADO + SCOPE IF
IF (A == 1 && B == -1 OR D){
	BOOL FLAG; 
	PRINTLN("CORRECTO IF_ANIDADO_1");
	IF (FLAG){
		INT Z = "ERROR SEMANTICO";
		INT X = 2; //VALIDAR SCOPE
		PRINTLN("CORRECTO IF_ANIDADO_2");
	}ELSE{
		PRINTLN("INCORRECTO");
	}
	PRINT("ESTO DEBERIA EJECUTARSE");
	PRINT(X); //ESTO NO DEBERIA EJECUTARSE
}ELSE{
	PRINTLN("INCORRECTO");

}

println("---------------------------------------------------------------------------");


'''

print("=== ANÁLISIS LÉXICO ===")
# Analizar léxicamente (tokeniza el código)
lexer.input(data)
for tok in lexer:
    print(tok)
lexer.lineno = 1

print("\n=== ANÁLISIS SINTÁCTICO ===")
# Ahora analiza sintácticamente (con el parser)
result = parser.parse(data)

print("______________________________")
if result is not None:
    for instruccion in result:

     
        instruccion.interpretar(ambitos)

    # Generar el reporte AST
    reporte_ast = ReporteAST()

    nodo_raiz = NodoRaiz(result)
    reporte_ast.graficar(nodo_raiz)


else:
    print("No se pudo generar el árbol de instrucciones (posible error de sintaxis).")
print("\nAnálisis completado exitosamente!")

ambitos.mostrar_todos_ambitos()
