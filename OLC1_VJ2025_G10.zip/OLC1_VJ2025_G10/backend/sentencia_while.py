from sentencia_break import Break
from sentencia_continue import Continue
from tablaSimbolos import TablaSimbolos

class While:
    # Clase que representa una sentencia while en el lenguaje
    def __init__(self, condicion, instrucciones):
        self.condicion = condicion  # La condición del while, debe ser una expresión booleana
        self.instrucciones = instrucciones  # Lista de instrucciones a ejecutar mientras la condición sea verdadera

    def interpretar(self, tabla_pila):
        # Ámbito general del while
        nombre_ambito = tabla_pila.generar_nombre_ambito("while")
        nueva_ts = TablaSimbolos()
        tabla_pila.apilar(nueva_ts, nombre_ambito)

        try:
            while True:
                condicion_resultado = self.condicion.interpretar(tabla_pila)

                if not isinstance(condicion_resultado, bool):
                    print("Error: la condición del while no es booleana.")
                    break

                if not condicion_resultado:
                    break

                # Ámbito por iteración
                nombre_ambito_iter = tabla_pila.generar_nombre_ambito("iter")
                tabla_iter = TablaSimbolos()
                tabla_pila.apilar(tabla_iter, nombre_ambito_iter)

                interrumpir = False# para manejar el break

                try:
                    for instr in self.instrucciones:
                        instr.interpretar(tabla_pila)
                except Continue:
                    # continua con la siguiente iteracion
                    pass
                except Break:
                    interrumpir = True
                finally:
                    tabla_pila.desapilar()# se cierra el ámbito de iteración
                if interrumpir:
                    break

        finally:
            tabla_pila.desapilar()# cerrar ámbito general del while