class Expresion_suma:
    def __init__(self,izq,der):
        self.izq=izq
        self.der=der

    def interpretar(self,pila_tabla):
        izq=self.izq.interpretar(pila_tabla)
        der=self.der.interpretar(pila_tabla)
        izq_es_char = isinstance(izq, str) and len(izq) == 1
        der_es_char = isinstance(der, str) and len(der) == 1
        if (isinstance(izq, str) and isinstance(der, bool)) or (isinstance(izq, bool) and isinstance(der, str)):
            return str(izq) + str(der)
        
        # concatena chat y str
        elif (isinstance(izq, str) and not izq_es_char and der_es_char) or (isinstance(der, str) and not der_es_char and izq_es_char):
            return str(izq) + str(der)
        
         # char + char
        elif izq_es_char and der_es_char:
           return  izq + der

        # suma de chat con un nuemro
        elif (isinstance(izq, (int, float)) and der_es_char):
            return izq + ord(der) # esa funcion or es la que pasa el char a ascii
        elif (isinstance(der, (int, float)) and izq_es_char):
            return ord(izq) + der
        
        # suma normal 
        elif isinstance(izq, (int, float)) and isinstance(der, (int, float)):
            return izq + der

        # Concatenación str + str
        elif isinstance(izq, str) or isinstance(der, str):
            if isinstance(izq, bool) or isinstance(der, bool):
                print(f"Error: No se puede concatenar str con tipo {type(izq).__name__ if isinstance(der, str) else type(der).__name__}")
                return None
            else:
                return str(izq) + str(der)

        # error
        else:
            print(f"Error: No se puede sumar tipos incompatibles: {type(izq).__name__} + {type(der).__name__}")
            return  None

class Expresion_resta:
    def __init__(self,izq,der):
        self.izq=izq
        self.der=der

    def interpretar(self,pila_tabla):
        izq=self.izq.interpretar(pila_tabla)
        der=self.der.interpretar(pila_tabla)
         # se uso para buscar los char 
        izq_es_char = isinstance(izq, str) and len(izq) == 1
        der_es_char = isinstance(der, str) and len(der) == 1

        # -------------------resta normal
        if isinstance(izq, (int, float)) and isinstance(der, (int, float)):
            return izq - der
            # resta de char con un nuemro
        elif (isinstance(izq, (int, float)) and der_es_char):
            return izq - ord(der) 
        elif (isinstance(der, (int, float)) and izq_es_char):
            return ord(izq) - der
        else:
            print(f"Error: No se puede sumar tipos incompatibles: {type(izq).__name__} + {type(der).__name__}")
            return None

class Expresion_multiplicacion:
    def __init__(self,izq,der):
        self.izq=izq
        self.der=der

    def interpretar(self,tabla_pila):
        izq=self.izq.interpretar(tabla_pila)
        der=self.der.interpretar(tabla_pila)

        # se uso para buscar los char 
        izq_es_char = isinstance(izq, str) and len(izq) == 1
        der_es_char = isinstance(der, str) and len(der) == 1

        # MULTIPLICACION entre int / float 
        if isinstance(izq, (int, float)) and isinstance(der, (int, float)):
            return izq * der
    # resta de char con un nuemro
        elif (isinstance(izq, (int, float)) and der_es_char):
            return izq * ord(der) 
        elif (isinstance(der, (int, float)) and izq_es_char):
            return ord(izq) * der
        else:
            print(f"Error: No se puede sumar tipos incompatibles: {type(izq).__name__} + {type(der).__name__}")
            return None

class Expresion_divicion:
    def __init__(self,izq,der, linea, columna):
        self.izq=izq
        self.der=der
        self.linea= linea
        self.columna= columna

    def interpretar(self,tabla_pila):
        izq=self.izq.interpretar(tabla_pila)
        der=self.der.interpretar(tabla_pila)

        # se uso para buscar los char 
        izq_es_char = isinstance(izq, str) and len(izq) == 1
        der_es_char = isinstance(der, str) and len(der) == 1
        if der == 0 or (der_es_char and ord(der) == 0):
            print(f"Error: División por cero (línea {self.linea}, columna {self.columna}).")

            return None

        if isinstance(izq, (int, float)) and isinstance(der, (int, float)):
            resultado = izq / der
            return int(resultado) if resultado.is_integer() else resultado

        # dividir de char con un nuemro
        elif (isinstance(izq, (int, float)) and der_es_char):
            return izq / ord(der) 
        elif (isinstance(der, (int, float)) and izq_es_char):
            return ord(izq) / der

        else:
            print(f"Error: No se puede sumar tipos incompatibles: {type(izq).__name__} + {type(der).__name__}")
            return None


class Expresion_potencia:
    def __init__(self,izq,der, linea, columna):
        self.izq=izq
        self.der=der
        self.linea= linea
        self.columna= columna

    def interpretar(self,ts):
        izq=self.izq.interpretar(ts)
        der=self.der.interpretar(ts)
        
        if isinstance(izq, (int, float)) and isinstance(der, (int, float)):
            return izq ** der
        else:
            print(f"Error: Tipos incompatibles para potencia: {type(izq).__name__} ** {type(der).__name__} (línea {self.linea}, columna {self.columna}).")
            return None
        

class Expresion_modulo:
    def __init__(self,izq,der, linea, columna):
        self.izq=izq
        self.der=der
        self.linea= linea
        self.columna= columna

    def interpretar(self,ts):
        izq=self.izq.interpretar(ts)
        der=self.der.interpretar(ts)

        if isinstance(izq, (int, float)) and isinstance(der, (int, float)):
            return izq % der

        else:
            print(f"Error: No se puede usar % con tipos incompatibles: {type(izq).__name__} % {type(der).__name__} (línea {self.linea}, columna {self.columna}).")
            return None
        

class Expresion_unaria:
    def __init__(self,expresion,signo):
        self.expresion=expresion
        self.signo=signo

    def interpretar(self, tabla_pila):
       
        if self.signo == '-':
            return -self.expresion.interpretar(tabla_pila)
        else:
            return +self.expresion.interpretar(tabla_pila)
       