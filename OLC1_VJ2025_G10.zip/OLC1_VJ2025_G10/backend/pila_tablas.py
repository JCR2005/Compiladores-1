class PilaTabla:
    def __init__(self):
        self.pila = []                # Pila de tablas de símbolos (ambitos activos)
        self.nombres_ambitos = []     # lista con los ambitos existentes
        self.contadores = {}          # contadores para las sentencias creadas
        self.ambitos_finalizados = []  

    def apilar(self, tabla, nombre_ambito):
        self.pila.append(tabla)
        self.nombres_ambitos.append(nombre_ambito)

    def desapilar(self):
        if self.pila:
            ambito = self.pila.pop()
            nombre = self.nombres_ambitos.pop()
            self.ambitos_finalizados.append((nombre, ambito)) #se guarda el ambito finalizado
            return ambito
        return None

    def cima(self): # esto representa el ambito actual
        if self.pila:
            return self.pila[-1]
        return None

    def ambito_actual(self): # para encontrar el nombre del ambito actual
        if self.nombres_ambitos:
            return self.nombres_ambitos[-1]
        return "global"

    # Buscar valor con alcance (de arriba hasta abajo de la pila)
    def obtener_valor_con_alcance(self, id):
        for tabla in reversed(self.pila):
            valor = tabla.obtener_valor(id)
            if valor is not None:
                return valor
        print(f"Error: Variable '{id}' no declarada en ningún ámbito.")
        return None
    
    # Buscar tipo_valor con alcance
    def obtener_tipo_valor_con_alcance(self, id):
        for tabla in reversed(self.pila):
            tipo_valor = tabla.obtener_tipo_valor(id)
            if tipo_valor is not None:
                return tipo_valor
        print(f"Error: Variable '{id}' no encontrada en ningún ámbito.")
        return None

    def actualizar_valor_con_alcance(self, id, nuevo_valor, linea, columna): # Para actualizar el valor de una variable en el ámbito actual o en uno superior
        for tabla in reversed(self.pila):
            if id in tabla.tabla:
                tabla.actualizar(id, nuevo_valor, linea, columna)
                return True
        print(f"Error: Variable pila '{id}' no declarada. No se puede actualizar (línea {linea}, columna {columna}).")
        return False
    
    def generar_nombre_ambito(self, tipo):
        if tipo not in self.contadores:
            self.contadores[tipo] = 1
        else:
            self.contadores[tipo] += 1

        padre = self.ambito_actual()
        if padre != "global":
            nuevo_nombre = f"{padre}->{tipo}{self.contadores[tipo]}"
        else:
            nuevo_nombre = f"{tipo}{self.contadores[tipo]}"
        return nuevo_nombre
    
    #Reporte
    def mostrar_todos_ambitos(self):
        print("=== Ámbitos activos ===")
        for nombre, tabla in zip(self.nombres_ambitos, self.pila):
            print(f"Ámbito: {nombre}")
            tabla.mostrar()
            print("--------------")

        print("=== Ámbitos finalizados ===")
        for nombre, tabla in self.ambitos_finalizados:
            print(f"Ámbito: {nombre}")
            tabla.mostrar()
            print("--------------")
