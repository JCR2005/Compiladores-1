from tablaSimbolos import TablaSimbolos
from sentencia_break import Break

class Switch:
    def __init__(self, expresion, casos, default):
        self.expresion = expresion
        self.casos = casos  # Lista de tuplas: (valor, instrucciones)
        self.default = default

    def interpretar(self, pila_tabla):
        valor = self.expresion.interpretar(pila_tabla)

        # Validar que la expresión del switch sea entera
        if isinstance(valor, int):
            valor = {"valor": valor, "tipo_valor": "int"}
        elif not isinstance(valor, dict) or valor.get("tipo_valor") != "int":
            print(f"Error: la expresión del switch debe ser de tipo entero.")
            return

        # Ámbito general del switch
        nombre_ambito_switch = pila_tabla.generar_nombre_ambito("switch")
        nueva_ts_switch = TablaSimbolos()
        pila_tabla.apilar(nueva_ts_switch, nombre_ambito_switch)

        try:
            for i, (case_valor, instrucciones) in enumerate(self.casos):
                valor_caso = case_valor.interpretar(pila_tabla)

                # Validar tipo del case
                if isinstance(valor_caso, int):
                    valor_caso = {"valor": valor_caso, "tipo_valor": "int"}
                elif not isinstance(valor_caso, dict) or valor_caso.get("tipo_valor") != "int":
                    print(f"Error: el valor de un case debe ser entero.")
                    continue

                # Coincidencia de case
                if valor_caso.get("valor") == valor.get("valor"):
                    nombre_case = pila_tabla.ambito_actual() + f"->case{valor_caso.get('valor')}"
                    nueva_ts_case = TablaSimbolos()
                    pila_tabla.apilar(nueva_ts_case, nombre_case)

                    try:
                        for instr in instrucciones:
                            instr.interpretar(pila_tabla)
                    except Break:
                        break
                    finally:
                        pila_tabla.desapilar()
                    return # Al encontrar el case, no se evalúan más

            # Ejecutar default si ningún case coincide
            if self.default:
                nombre_default = pila_tabla.generar_nombre_ambito("default")
                nueva_ts_default = TablaSimbolos()
                pila_tabla.apilar(nueva_ts_default, nombre_default)
                try:
                    for instr in self.default:
                        instr.interpretar(pila_tabla)
                finally:
                    pila_tabla.desapilar()
        finally:
            pila_tabla.desapilar()
