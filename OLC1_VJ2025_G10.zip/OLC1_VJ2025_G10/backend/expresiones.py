class Expresion_id:
    def __init__(self,id):
        self.id=id

    def interpretar(self, pila_tabla):
        return pila_tabla.obtener_valor_con_alcance(self.id)

class Expresion_numero:
    def __init__(self,numero):
        self.numero=numero

    def interpretar(self,ts):
       return self.numero

class Expresion_decimal_numero:
    def __init__(self,numero):
        self.numero=numero

    def interpretar(self,ts):
       return self.numero
    
class Expresion_cadena:
    def __init__(self,cadena):
        self.cadena=cadena

    def interpretar(self,ts):
       return self.cadena

class Expresion_caracter:
    def __init__(self,caracter):
        self.caracter=caracter

    def interpretar(self,ts):
       return self.caracter

class Expresion_booleana:
    def __init__(self,bool):
        self.bool=bool

    def interpretar(self,ts):
       valor_b = self.bool.lower()
       if valor_b == "true":
              return True
       return False
       
class Expresion_parentesis:
    def __init__(self,expresion):
        self.expresion=expresion

    def interpretar(self,ts):
       return self.expresion

 