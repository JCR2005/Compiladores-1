from flask import Flask, request, jsonify
from flask_cors import CORS
from lexer import lexer, tokenize_with_column
from parser import parser, ambitos
from sentencia_while import While
import sys
import io
from tablaSimbolos import TablaSimbolos


app = Flask(__name__)
CORS(app) 

@app.route('/interpret', methods=['POST'])
def interpret():
    try:
        data = request.get_json()
        code = data.get('code', '')

        old_stdout = sys.stdout
        new_stdout = io.StringIO()
        sys.stdout = new_stdout

        lexer.lineno = 1
        ambitos.clear()
        ambitos.append(TablaSimbolos())

        tokens = tokenize_with_column(code)
        lexer.lineno = 1
        lexer.input(code)
        result = parser.parse(code)

        output = []
        if result is not None:
            for instruccion in result:
                instruccion.interpretar(ambitos[-1])
            output.append(new_stdout.getvalue())
        else:
            output.append("Error: No se pudo generar el árbol de instrucciones (posible error de sintaxis).")

        sys.stdout = old_stdout

        symbol_table = []
        for id, datos in ambitos[-1].tabla.items():
            symbol_table.append({
                'id': id,
                'tipo': datos['tipo'],
                'tipo_valor': datos['tipo_valor'],
                'ambito': datos['ambito'],
                'valor': datos['valor'],
                'linea': datos['linea'],
                'columna': datos['columna']
            })

        return jsonify({
            'status': 'success',
            'output': ''.join(output),
            'tokens': tokens,
            'symbol_table': symbol_table
        })

    except Exception as e:
        sys.stdout = old_stdout
        return jsonify({
            'status': 'error',
            'message': str(e)
        }), 500

if __name__ == '__main__':
    app.run(debug=True, port=5000)