class NodoError(Exception):
    def __init__(self, mensaje):
        self.mensaje = mensaje

    def interpretar(self,ts):
      print(f"\033[91m: {self.mensaje}\033[0m")

