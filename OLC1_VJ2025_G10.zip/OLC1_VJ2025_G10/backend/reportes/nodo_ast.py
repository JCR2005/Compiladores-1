class NodoRaiz:
    def __init__(self, instrucciones):
        self.instrucciones = instrucciones