class Expresion_logica:
    def __init__(self,izq,der,operador, linea, columna):
        self.izq=izq
        self.der=der
        self.operador=operador
        self.linea= linea
        self.columna= columna

    def interpretar(self,ts):
        izq=self.izq.interpretar(ts)
        der=self.der.interpretar(ts)

        if self.operador == '&&':
            return  bool(bool(izq) and bool(der))

        elif self.operador == '||':
            return  bool(bool(izq) or bool(der))

        elif self.operador == '^':
            return  bool(bool(izq) != bool(der))
        
        else: 
            print(f"Error: no se reconoce expresión logica")
            return  None
