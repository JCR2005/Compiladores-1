from parser import parser
import lexer

entrada = '''Vector[int] cube(2,2,2) = [[ [ 1,  2],  [ 3,  4]],
                           [ [ 5,  6],  [ 7,  8]]];

'''

resultado = parser.parse(entrada)
print("Resultado :")
print(resultado)
