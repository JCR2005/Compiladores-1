# parser.py
import ply.yacc as yacc
from lexer import tokens

def p_declaracion_vector(t):
    '''declaracion : VECTOR CORCHETEIZQ TIPO CORCHETEDER ID PARENIZQ dimensiones PARENDER PUNTOYCOMA
                   | VECTOR CORCHETEIZQ TIPO CORCHETEDER ID PARENIZQ dimensiones PARENDER IGUAL asignacion PUNTOYCOMA'''
    if len(t) == 10:
        t[0] = ('DECLARACION', t[3], t[5], t[7])
    else:
        t[0] = ('Vector', t[3], t[5], t[7], t[10])

def p_dimensiones(t):
    '''dimensiones : ENTERO
                   | dimensiones COMA ENTERO'''
    if len(t) == 2:
        t[0] = [t[1]]
    else:
        t[0] = t[1] + [t[3]]

# ** Nuevo **: un elemento puede ser un número o una lista anidada
def p_elemento(t):
    '''elemento : expresion
                | lista_vectores'''
    t[0] = t[1]

# Lista de elementos, separados por comas
def p_lista_expresiones(t):
    '''lista_expresiones : elemento
                         | lista_expresiones COMA elemento'''
    if len(t) == 2:
        t[0] = [t[1]]
    else:
        t[0] = t[1] + [t[3]]

# Una “lista” de vectores es simplemente corchetes que contienen elementos
def p_lista_vectores(t):
    'lista_vectores : CORCHETEIZQ lista_expresiones CORCHETEDER'
    t[0] = t[2]

# Expr básicas: entero o decimal
def p_expresion(t):
    '''expresion : ENTERO
                 | DECIMAL'''
    t[0] = t[1]

# Asignación: uno o varios bloques listados
def p_asignacion(t):
    '''asignacion : lista_vectores
                  | asignacion COMA lista_vectores'''
    if len(t) == 2:
        t[0] = [t[1]]
    else:
        t[0] = t[1] + [t[3]]

def p_error(t):
    if t:
        print(f"Error de sintaxis: token inesperado '{t.value}' en línea {t.lineno}")
    else:
        print("Error de sintaxis: entrada incompleta")

parser = yacc.yacc()
