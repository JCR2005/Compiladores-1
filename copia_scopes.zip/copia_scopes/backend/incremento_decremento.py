class IncrementoDecremento:
    def __init__(self, id, operador, fila, columna):
        self.id = id
        self.operador = operador
        self.fila = fila
        self.columna = columna

    def interpretar(self, pila_tabla):
        actual = pila_tabla.obtener_valor_con_alcance(self.id)
        if not isinstance(actual, (int, float)):
            print(f"Error: solo se puede {self.operador} sobre números. Línea {self.fila}, Columna {self.columna}")
            return
        if self.operador == '++':
            nuevo = actual + 1
        else:
            nuevo = actual - 1
        pila_tabla.actualizar_valor_con_alcance(self.id, nuevo, self.fila, self.columna)
