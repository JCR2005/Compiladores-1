from sentencia_break import Break
from sentencia_continue import Continue
from tablaSimbolos import TablaSimbolos

class expresion_condicion:
    def __init__(self, expresion):
        self.expresion = expresion

    # Evalúa la condición del for
    def interpretar(self, tabla_pila):
        return self.expresion.interpretar(tabla_pila)

class expresion_actualizacion:
    def __init__(self, expresion):
        self.expresion = expresion

    # Ejecuta la expresión de actualización (i++, i = i + 1, etc.)
    def interpretar(self, tabla_pila):
        self.expresion.interpretar(tabla_pila)

class regla_for:
    def __init__(self, inicial, condicion, actualizacion, bloque):
        self.inicial = inicial
        self.condicion = condicion
        self.actualizacion = actualizacion
        self.bloque = bloque

    # Ejecuta la lógica de un ciclo for clásico
    def interpretar(self, tabla_pila):
        # Ámbito general del for
        nombre_ambito_for = tabla_pila.generar_nombre_ambito("for")
        tabla_for = TablaSimbolos()
        tabla_pila.apilar(tabla_for, nombre_ambito_for)

        try:
            self.inicial.interpretar(tabla_pila)

            while True:
                condicion_resultado = self.condicion.interpretar(tabla_pila)
                if not isinstance(condicion_resultado, bool):
                    print("Error: La condición del for no es booleana.")
                    break
                if not condicion_resultado:
                    break

                #Ambito de iteración
                nombre_iter = tabla_pila.generar_nombre_ambito("iter")
                tabla_iter = TablaSimbolos()
                tabla_pila.apilar(tabla_iter, nombre_iter)

                hay_break = False
                hay_continue = False

                try:
                    for instruccion in self.bloque:
                        instruccion.interpretar(tabla_pila)
                except Continue:
                    hay_continue = True
                except Break:
                    hay_break = True
                finally:
                    tabla_pila.desapilar() # se cierra el ámbito de iteración

                if hay_break:
                    break

                self.actualizacion.interpretar(tabla_pila)

                if hay_continue:
                    continue #Sigue a la siguiente iteración

        finally:
            tabla_pila.desapilar() # cerrar ámbito del for