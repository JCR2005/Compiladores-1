import ply.lex as lex

# Palabras reservadas
reservadas = {
    'int': 'INT',
    'float': 'FLOAT',
    'bool': 'BOOL',
    'char': 'CHAR',
    'str': 'STR',
    'if': 'IF',
    'else': 'ELSE',
    'while': 'WHILE',
    'for': 'FOR',
    'do': 'DO',
    'switch': 'SWITCH',
    'case': 'CASE',
    'break': 'BREAK',
    'continue': 'CONTINUE',
    'default': 'DEFAULT',
    'true': 'TRUE',
    'false': 'FALSE',
    'println': 'PRINTLN',
    'break': 'BREAK',
}

# Lista de tokens
tokens = [
    'IGUALIGUAL',
    'ID',
    'IGUAL',
    'ENTERO',
    'DECIMAL',
    'CADENA',
    'CARACTER',
    'PUNTOYCOMA',
    'LLAVEIZQ',
    'LLAVEDER',
    'PARIZQ',
    'PARDER',
    'MAS',
    'MENOS',
    'POTENCIA',
    'MULTIPLICACION',
    'DIVISION',
    'PORCENTAJE',
    'MAYORIGUAL',
    'MENORIGUAL',
    'DIFERENTE',
    'MAYOR',
    'MENOR',
    'AND', 
    'OR',
    'XOR',
    'DOSPUNTOS'
] + list(reservadas.values())

# Ignorar espacios y tabs
t_ignore = ' \t'

# Tokens simples
t_IGUALIGUAL = r'=='
t_IGUAL = r'='
t_PUNTOYCOMA = r';'
t_LLAVEIZQ = r'\{'
t_LLAVEDER = r'\}'
t_PARIZQ = r'\('
t_PARDER = r'\)'
t_MAS = r'\+'
t_MENOS = r'-'
t_POTENCIA = r'\*\*'
t_MULTIPLICACION = r'\*'
t_DIVISION = r'/'
t_PORCENTAJE = r'%'
t_MAYORIGUAL = r'>='
t_MENORIGUAL = r'<='
t_DIFERENTE = r'!='
t_MAYOR = r'>'
t_MENOR = r'<'
t_AND = r'&&'
t_OR = r'\|\|'
t_XOR = r'\^'
t_DOSPUNTOS = r':'

# Función para calcular la posición en la línea
def find_column(input_text, token):
    """Calcula la posición de la columna basándose en el último salto de línea"""
    line_start = input_text.rfind('\n', 0, token.lexpos) + 1
    return (token.lexpos - line_start) + 1

# Comentarios
def t_COMENTARIO_MULTILINEA(t):
    r'/\*[\s\S]*?\*/'
    t.lexer.lineno += t.value.count('\n')
    pass

def t_COMENTARIO_LINEA(t):
    r'\/\/.*'
    pass

# Identificadores y palabras reservadas
def t_ID(t):
    r'[a-zA-Z_][a-zA-Z0-9_]*'
    t.value = t.value.lower()
    t.type = reservadas.get(t.value, 'ID') 
    return t

#NUMEROS DECIMALES 
def t_DECIMAL(t):
    r'\d+\.\d+'
    t.value = float(t.value)
    return t


# Números enteros
def t_ENTERO(t):
    r'\d+'
    t.value = int(t.value)
    return t

# Cadenas de texto
def t_CADENA(t):
    r'\"([^\\\n]|(\\.))*?\"'
    t.value = bytes(t.value[1:-1], "utf-8").decode("unicode_escape")
    return t

# Caracteres individuales
def t_CARACTER(t):
    r'\'([^\\\n]|(\\.))\''
    t.value = bytes(t.value[1:-1], "utf-8").decode("unicode_escape")
    return t

# Nuevas líneas
def t_newline(t):
    r'\n+'
    t.lexer.lineno += len(t.value)

# Errores
def t_error(t):
    print(f"Error léxico: carácter no válido '{t.value[0]}' en línea {t.lineno}")
    t.lexer.skip(1)

# Crear el lexer
lexer = lex.lex()

# Función para mostrar tokens con posición correcta
def tokenize_with_column(data):
    lexer.input(data)
    tokens = []
    for token in lexer:
        # Calcular la columna real
        column = find_column(data, token)
        # Crear un nuevo token con la información de columna
        token_info = {
            'type': token.type,
            'value': token.value,
            'line': token.lineno,
            'column': column,
            'lexpos': token.lexpos
        }
        tokens.append(token_info)
        # print(f"LexToken({token.type}, {repr(token.value)}, {token.lineno}, {column})")
    return tokens
