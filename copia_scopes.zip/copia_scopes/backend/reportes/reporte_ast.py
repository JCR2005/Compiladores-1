from graphviz import Digraph

class ReporteAST:
    def __init__(self):
        self.contador = 0
        self.dot = Digraph(comment="AST")
    
    def generar_id(self):
        self.contador += 1
        return f"n{self.contador}"

    def graficar(self, nodo_raiz):
        self._recorrer(nodo_raiz)
        self.dot.render('AST_REPORT', format='PDF', cleanup=True)
        print("AST generado correctamente")

    def _recorrer(self, nodo):
        if nodo is None:
            return None

        # Si el nodo es un valor (str, int, float), mostrarlo como texto
        if isinstance(nodo, (str, int, float)):
            actual_id = self.generar_id()
            self.dot.node(actual_id, str(nodo))
            return actual_id

        # Si es una clase, toma el nombre de clase
        nombre_nodo = type(nodo).__name__
        actual_id = self.generar_id()
        self.dot.node(actual_id, nombre_nodo)

        # Procesar atributos hijos a partir del __dict__
        if hasattr(nodo, '__dict__'):
            for k, v in nodo.__dict__.items():
                if isinstance(v, list):
                    for item in v:
                        hijo_id = self._recorrer(item)
                        if hijo_id:
                            self.dot.edge(actual_id, hijo_id)
                else:
                    hijo_id = self._recorrer(v)
                    if hijo_id:
                        self.dot.edge(actual_id, hijo_id)
        return actual_id