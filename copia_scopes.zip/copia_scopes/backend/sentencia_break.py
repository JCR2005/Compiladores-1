class Break(Exception):
    def __init__(self):
        pass

    def interpretar(self, ts):

        raise self