from lexer import lexer  # Importa el lexer
from parser import parser, ambitos  # Importa el parser
from reportes.reporte_ast import ReporteAST 
from reportes.nodo_ast import NodoRaiz

data = '''
println("---------------------------------------------------------------------------");
println("------------------------------ WHILE --------------------------------------");
println("---------------------------------------------------------------------------");

INT i = 0;

WHILE (i < 5) {
    IF (i == 2) {
        i = i + 1;
        CONTINUE; // SALTA LA IMPRESIÓN DE i == 2
    }
    PRINTLN(i);
    IF (i == 4) {
        BREAK; // FINALIZA EL WHILE ANTES DE i == 5
    }
    i = i + 1;
}

'''

print("=== ANÁLISIS LÉXICO ===")
# Analizar léxicamente (tokeniza el código)
lexer.input(data)
for tok in lexer:
    print(tok)
lexer.lineno = 1

print("\n=== ANÁLISIS SINTÁCTICO ===")
# Ahora analiza sintácticamente (con el parser)
result = parser.parse(data)

print("______________________________")
if result is not None:
    for instruccion in result:
        instruccion.interpretar(ambitos)

    # Generar el reporte AST
    reporte_ast = ReporteAST()

    nodo_raiz = NodoRaiz(result)
    reporte_ast.graficar(nodo_raiz)


else:
    print("No se pudo generar el árbol de instrucciones (posible error de sintaxis).")
print("\nAnálisis completado exitosamente!")

ambitos.mostrar_todos_ambitos()
