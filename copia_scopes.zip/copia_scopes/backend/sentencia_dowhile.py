from sentencia_break import Break
from sentencia_continue import Continue
from tablaSimbolos import TablaSimbolos

class DoWhile:
    def __init__(self, instrucciones, condicion, fila, columna):
        self.instrucciones = instrucciones
        self.condicion = condicion
        self.fila = fila
        self.columna = columna

    def interpretar(self, tabla_pila):
        # Ámbito general del do-while
        nombre_ambito = tabla_pila.generar_nombre_ambito("do-while")
        nueva_ts = TablaSimbolos()
        tabla_pila.apilar(nueva_ts, nombre_ambito)

        try:
            while True:
                # Ámbito por iteración
                nombre_ambito_iter = tabla_pila.generar_nombre_ambito("iter")
                tabla_iter = TablaSimbolos()
                tabla_pila.apilar(tabla_iter, nombre_ambito_iter)

                interrumpir = False # para saber si hubo break

                try:
                    for instruccion in self.instrucciones:
                        instruccion.interpretar(tabla_pila)
                except Continue:
                    pass 
                except Break:
                    interrumpir = True
                finally:
                    tabla_pila.desapilar()# se cierra el ámbito de iteración

                if interrumpir:
                    break

                condicion_resultado = self.condicion.interpretar(tabla_pila)

                if not isinstance(condicion_resultado, bool):
                    print(f"Error semántico: la condición del do-while debe ser booleana. Línea {self.fila}, Columna {self.columna}")
                    break

                if not condicion_resultado:
                    break

        finally:
            tabla_pila.desapilar()# desapilar el ambito general del do-while