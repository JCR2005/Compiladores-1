class Expresion_relacional:
    def __init__(self,izq,der,operador, linea, columna):
        self.izq=izq
        self.der=der
        self.operador=operador
        self.linea= linea
        self.columna= columna

    def interpretar(self,ts):
        izq=self.izq.interpretar(ts)
        der=self.der.interpretar(ts)
        
        izq_es_char = isinstance(izq, str) and len(izq) == 1
        der_es_char = isinstance(der, str) and len(der) == 1
        
        if isinstance(izq, (int, float)) and isinstance(der, (int, float)):
            if self.operador == '==':
                return bool(izq == der)
            elif self.operador == '!=':
                return bool(izq != der)
            elif  self.operador == '<':
                return bool(izq < der)
            elif  self.operador == '<=':
                return bool(izq <= der)
            elif  self.operador == '>':
                return bool(izq > der)
            elif  self.operador == '>=':
                return bool(izq >= der)

        elif (isinstance(izq, (int, float)) and der_es_char):

            if  self.operador == '==':
                return bool(izq == ord(der))
            elif  self.operador == '!=':
                return bool(izq != ord(der))
            elif  self.operador == '<':
                return bool(izq < ord(der))
            elif  self.operador == '<=':
                return bool(izq <= ord(der))
            elif  self.operador == '>':
                return bool(izq > ord(der))
            elif  self.operador == '>=':
                return bool(izq >= ord(der))
            
        elif (isinstance(izq, (int, float)) and der_es_char):

            if self.operador == '==':
                return bool(izq == ord(der))
            elif  self.operador == '!=':
                return bool(izq != ord(der))
            elif  self.operador == '<':
                return bool(izq < ord(der))
            elif  self.operador == '<=':
                return bool(izq <= ord(der))
            elif  self.operador == '>':
                return bool(izq > ord(der))
            elif  self.operador == '>=':
                return bool(izq >= ord(der))

        # char char
        elif izq_es_char and der_es_char:
            if  self.operador == '==':
                return bool(izq == der)
            elif  self.operador == '!=':
                return bool(izq != der)
            elif  self.operador == '<':
                return bool(izq < der)
            elif  self.operador == '<=':
                return bool(izq <= der)
            elif  self.operador == '>':
                return bool(izq > der)
            elif  self.operador == '>=':
                return bool(izq >= der)


        # str str
        elif isinstance(izq, str) or isinstance(der, str):
            if  self.operador == '==':
                return bool(izq == der)
            elif  self.operador == '!=':
                return bool(izq != der)
            elif  self.operador == '<':
                return bool(izq < der)
            elif  self.operador == '<=':
                return bool(izq <= der)
            elif  self.operador == '>':
                return bool(izq > der)
            elif  self.operador == '>=':
                return bool(izq >= der)  

        # bool bool
        elif isinstance(izq, bool) or isinstance(der, bool):
            if  self.operador == '==':
                return bool(izq == der)
            elif  self.operador == '!=':
                return bool(izq != der)
            elif  self.operador == '<':
                return bool(izq < der)
            elif  self.operador == '<=':
                return bool(izq <= der)
            elif  self.operador == '>':
                return bool(izq > der)
            elif  self.operador == '>=':
                return bool(izq >= der)
            
        else:
            print(f"Error: es invalida esta comparación {type(izq).__name__} y {type(der).__name__}")
            return None
