import ply.yacc as yacc
from lexer import tokens # Importa los tokens desde lexer.py
from tablaSimbolos import TablaSimbolos
from patronInterprete import *
from incremento_decremento import IncrementoDecremento
from expresiones import *
from pila_tablas import PilaTabla

#sentencias
from sentencia_if import If
from sentencia_switch import Switch
from sentencia_dowhile import DoWhile
from sentencia_for import*
from sentencia_while import While
from sentencia_break import Break
from sentencia_continue import Continue

#operadores 
from operador_aritmetico import *
from operador_relacional import *
from operador_logico import *


ambitos = PilaTabla() 
ambitos.apilar(TablaSimbolos(), "global") # Apilamos la tabla de símbolos global


# Reglas de precedencia
precedence = (
    ('left', 'IGUALIGUAL', 'DIFERENTE'),
    ('left', 'MENOR', 'MENORIGUAL', 'MAYOR', 'MAYORIGUAL'),
    ('left', 'MAS', 'MENOS'),
    ('left', 'MULTIPLICACION', 'DIVISION', 'PORCENTAJE'),
    ('right', 'POTENCIA'),
    ('right', 'MENOSNUEVO', 'MASNUEVO'),  
)

# Regla principal: programa puede ser una lista de declaraciones
def p_programa(t):
    '''programa : programa declaracion
                | programa asignacion
                | programa println
                | declaracion
                | asignacion
                | println'''
    if len(t) == 2:
        t[0] = [t[1]]
    else:
        t[0] = t[1] + [t[2]]

# Regla para la declaración de una variable
def p_declaracion(t):
    'declaracion : tipo ID PUNTOYCOMA'
    linea = t.slice[2].lineno
    columna = find_column(t.lexer.lexdata, t.slice[2])
    tipo_var = t[1]
    nombre_var = t[2].lower()  # Convertir el nombre de la variable a minúsculas
    t[0]=Declaracion(nombre_var,"variable", tipo_var, None, linea, columna)

# Regla para declaración con asignación
def p_declaracion_asignacion(t):
    'declaracion : tipo ID IGUAL expresion PUNTOYCOMA'
    linea = t.slice[2].lineno
    columna = find_column(t.lexer.lexdata, t.slice[2])
    tipo_var = t[1]
    nombre_var = t[2].lower()  # Convertir el nombre de la variable a minúsculas
    valor = t[4]
    t[0]=Declaracion_asignacion(nombre_var,"variable", tipo_var, None, valor,linea,columna) 


# Regla para asignación
def p_asignacion(t):
    
    'asignacion : ID IGUAL expresion PUNTOYCOMA'
    columna = find_column(t.lexer.lexdata, t.slice[2])
    linea = t.slice[2].lineno
    nombre_var = t[1].lower()  # Convertir el nombre de la variable a minúsculas
    valor = t[3]
    t[0]=Asignacion(nombre_var,valor,linea,columna)
   

# Expresiones numéricas
def p_expresion_numero(t):
    'expresion : ENTERO'
    t[0] = Expresion_numero(t[1])
  

def p_expresion_decimal(t):
    'expresion : DECIMAL'
    t[0] =  Expresion_decimal_numero(t[1])

def p_expresion_cadena(t):
    'expresion : CADENA'
    t[0] = Expresion_cadena(t[1])

def p_expresion_caracter(t):
    'expresion : CARACTER'
    t[0] = Expresion_caracter(t[1])

def p_expresion_booleano(t):
    '''expresion : TRUE
                 | FALSE'''
    t[0] = Expresion_booleana(t[1])


def p_expresion_parentesis(t):
    'expresion : PARIZQ expresion PARDER'
    t[0] = Expresion_parentesis(t[2])


#----------------------------SUMA------------------------------------------------
def p_expresion_suma(t):
    'expresion : expresion MAS expresion'
    izq = t[1]
    der = t[3]
    t[0]=Expresion_suma(izq,der)

#----------------------------RESTA------------------------------------------------
def p_expresion_resta(t):
    'expresion : expresion MENOS expresion'
    izq = t[1]
    der = t[3]
    t[0]=Expresion_resta(izq,der)

#----------------------------MULTIPLICACION------------------------------------------------


def p_expresion_multiplicacion(t):
    'expresion : expresion MULTIPLICACION expresion'
    izq = t[1]
    der = t[3]
    t[0]=Expresion_multiplicacion(izq,der)

#----------------------------DIVISION------------------------------------------------


def p_expresion_division(t):
    'expresion : expresion DIVISION expresion'
    izq = t[1]
    der = t[3]
    linea = t.slice[2].lineno
    columna = find_column(t.lexer.lexdata, t.slice[2])
    t[0]=Expresion_divicion(izq,der,linea,columna)


#----------------------------MODULO------------------------------------------------
def p_expresion_modulo(t):
    'expresion : expresion PORCENTAJE expresion'
    izq = t[1]
    der = t[3]
    linea = t.slice[2].lineno
    columna = find_column(t.lexer.lexdata, t.slice[2])
    t[0]=Expresion_modulo(izq,der,linea,columna)

#----------------------------POTENCIA------------------------------------------------
def p_expresion_potencia(t):
    'expresion : expresion POTENCIA expresion'
    izq = t[1]
    der = t[3]
    linea = t.slice[2].lineno
    columna = find_column(t.lexer.lexdata, t.slice[2])
    t[0]=Expresion_potencia(izq,der,linea,columna)
  
  
def p_expresiones_logicas(t):

    '''expresion : expresiones_relacionales '''

    t[0]=t[1]

def p_expresion_logica(t):
    '''
    expresion : expresion AND expresion
              | expresion OR expresion
              | expresion XOR expresion
    '''
    izq = t[1]
    operador= t[2]
    der = t[3] 
    linea = t.slice[2].lineno
    columna = find_column(t.lexer.lexdata, t.slice[2])
    t[0]=Expresion_logica(izq, der, operador,linea,columna)
  

#----------------------------EXPRESIONES RELACIONAL------------------------------------------------
def p_expresion_relacional(t):
    '''expresiones_relacionales : expresion IGUALIGUAL expresion
                                | expresion DIFERENTE expresion
                                | expresion MENOR expresion
                                | expresion MENORIGUAL expresion
                                | expresion MAYOR expresion
                                | expresion MAYORIGUAL expresion'''
    izq = t[1]
    operador= t[2]
    der = t[3] 
    linea = t.slice[2].lineno
    columna = find_column(t.lexer.lexdata, t.slice[2])
    t[0]=Expresion_relacional(izq, der, operador,linea,columna)



# --------------------- UNARIOS ---------------------
def p_expresion_unaria(t):
    '''expresion : MENOS expresion %prec MENOSNUEVO
                 | MAS expresion %prec MASNUEVO'''
    
    t[0]=Expresion_unaria(t[2],t[1])

# Regla para los tipos de datos
def p_tipo(t):
    '''tipo : INT
            | FLOAT
            | BOOL
            | CHAR
            | STR'''
    t[0] = t[1]

# --------- Sentencia break ---------------
def p_break(t):
    'declaracion : BREAK PUNTOYCOMA'
    t[0] = Break()

# --------- Sentencia continue ---------------
def p_continue(t):
    'declaracion : CONTINUE PUNTOYCOMA'
    t[0] = Continue(t.slice[1].lineno, find_column(t.lexer.lexdata, t.slice[1]))


def find_column(input_text, token):
    line_start = input_text.rfind('\n', 0, token.lexpos) + 1
    return (token.lexpos - line_start) + 1

# Instruccion  print
def p_print(t):
  
    'println : PRINTLN PARIZQ expresion PARDER PUNTOYCOMA'
  
    t[0]=Printnl(t[3])
    

def p_expresion_id(t):
    'expresion : ID'
    id=t[1]
    t[0] = Expresion_id(id)
   
# Manejo de errores
def p_error(t):
    if t:
        print(f"Error de sintaxis en token '{t.value}' (tipo: {t.type}) en línea {t.lineno}")
    else:
        print("Error de sintaxis: fin de archivo inesperado")


# --------- Incremento y Decremento ---------------
def p_incremento_declaracion(t):
    'declaracion : ID MAS MAS PUNTOYCOMA'
    t[0] = IncrementoDecremento(t[1], '++', t.slice[2].lineno, find_column(t.lexer.lexdata, t.slice[2]))

def p_decremento_declaracion(t):
    'declaracion : ID MENOS MENOS PUNTOYCOMA'
    t[0] = IncrementoDecremento(t[1], '--', t.slice[2].lineno, find_column(t.lexer.lexdata, t.slice[2]))
    


# --------- Para la sentencia if, else, else if ---------------

# regla para if sin else
def p_if_simple(t):
    'declaracion : IF PARIZQ expresion PARDER LLAVEIZQ programa LLAVEDER'
    t[0] = If(t[3], t[6], None)

# regla para if con else o else if
def p_if_con_else(t):
    'declaracion : IF PARIZQ expresion PARDER LLAVEIZQ programa LLAVEDER else_block'
    t[0] = If(t[3], t[6], t[8])

# Bloque else o else if
def p_else_block_else(t):
    '''else_block : ELSE LLAVEIZQ programa LLAVEDER'''
    t[0] = t[3]

def p_else_block_elseif(t):
    '''else_block : ELSE IF PARIZQ expresion PARDER LLAVEIZQ programa LLAVEDER else_block'''
    # Anidamos otro if dentro del else
    t[0] = If(t[4], t[7], t[9])


# --------- Para la sentencia switch, case, default ---------------

# regla para la sentencia switch
def p_switch(t):
    '''declaracion : SWITCH PARIZQ expresion PARDER LLAVEIZQ casos default_opt LLAVEDER'''
    t[0] = Switch(t[3], t[6], t[7])

# reglas para los casos dentro del switch
def p_casos_varios(t):
    '''casos : casos caso
             | caso'''
    if len(t) == 2:
        t[0] = [t[1]]
    else:
        t[0] = t[1] + [t[2]]

# regla para un caso individual
def p_caso(t):
    'caso : CASE expresion DOSPUNTOS programa BREAK PUNTOYCOMA'
    t[0] = (t[2], t[4])  # valor del case y su bloque de instrucciones


# esto es para el caso default
def p_default_opt(t):
    '''default_opt : DEFAULT DOSPUNTOS programa BREAK PUNTOYCOMA
                   | empty'''
    if len(t) > 2:
        t[0] = t[3]
    else:
        t[0] = None

def p_empty(t):
    'empty :'
    pass

# ---------- sentencia do while ----------------

#para que funcione el do while
def p_dowhile(t):
    '''declaracion : DO LLAVEIZQ programa LLAVEDER WHILE PARIZQ expresion PARDER PUNTOYCOMA'''
    t[0] = DoWhile(t[3], t[7], t.lineno(1), t.lexpos(1))


# --------- Para la sentencia while ---------------
def p_while(t):
    'declaracion : WHILE PARIZQ expresion PARDER LLAVEIZQ programa LLAVEDER'
    t[0] = While(t[3], t[6])

# Regla gramatical para intrucciòn for

def p_incremento_for(t):
    'incremento_for : ID MAS MAS '
    t[0] = IncrementoDecremento(t[1], '++', t.slice[2].lineno, find_column(t.lexer.lexdata, t.slice[2]))

def p_decremento_for(t):
    'decremento_for : ID MENOS MENOS '
    t[0] = IncrementoDecremento(t[1], '--', t.slice[2].lineno, find_column(t.lexer.lexdata, t.slice[2]))

def p_asignacion_for(t):
    
    'asignacion_for : ID IGUAL expresion'
    columna = find_column(t.lexer.lexdata, t.slice[2])
    linea = t.slice[2].lineno
    nombre_var = t[1]
    valor = t[3]
    t[0]=Asignacion(nombre_var,valor,linea,columna)

def p_for(t):
    'declaracion : FOR PARIZQ expresion_inicial  expresion_condicion PUNTOYCOMA expresion_actualizacion  PARDER LLAVEIZQ programa LLAVEDER'

    t[0]=regla_for(t[3],t[4],t[6],t[9])

def p_expresion_inicial(t):
    '''expresion_inicial : declaracion
                         | asignacion'''
    
    t[0]=t[1]

def p_expresion_condicion(t):
    '''expresion_condicion : expresiones_relacionales'''
    t[0]=expresion_condicion(t[1])


def p_expresion_actualizacion(t):
    '''expresion_actualizacion : incremento_for
                               | decremento_for
                               | asignacion_for'''
    t[0] = expresion_actualizacion(t[1])

# Crear el parser
parser = yacc.yacc()


