class TablaSimbolos:
    def __init__(self):
        self.tabla = {}

    def insertar(self, id, tipo, tipo_valor, ambito, valor, linea, columna):
        if id in self.tabla:
            print(f"Error: '{id}' ya fue declarado (línea {linea}, columna {columna}).")
            return

        self.tabla[id] = {
            "tipo": tipo,              
            "tipo_valor": tipo_valor,  
            "ambito": ambito,
            "valor": valor,
            "linea": linea,
            "columna": columna
        }

    def actualizar(self, id, nuevo_valor, linea, columna):
        if id not in self.tabla:
            #print(f"Error: '{id}' no ha sido declarado aún. No se puede actualizar (línea {linea}, columna {columna}).")
            return

        self.tabla[id]["valor"] = nuevo_valor
      

    def mostrar(self):
        for id, datos in self.tabla.items():
            print(f"{id}: {datos}")


    def obtener_valor(self, id):

        if id in self.tabla:
            return self.tabla[id]['valor']
        else:
            #print(f"Error: '{id}' no está declarado.")
            return None

    def obtener_tipo_valor(self, id):
        if id in self.tabla:
            return self.tabla[id]['tipo_valor']
        else:
            #print(f"Error: '{id}' no está declarado.")
            return None
